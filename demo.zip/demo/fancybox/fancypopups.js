
		$(document).ready(function() {
			/*
			*   Examples - images
			*/
			
			$(document).ready(function() {
 $("a.overlay-flash").fancybox({
 'padding'                : 0,
 'zoomOpacity'            : true,
 'zoomSpeedIn'            : 500,
 'zoomSpeedOut'            : 500,
 'overlayOpacity'        : 0.75,
                'autoDimensions'        : true,
 'hideOnContentClick'    : false
 });
});
			
			
			
			        $(".featured").fancybox({
                'overlayOpacity'        : 0.7,
                'overlayColor'          : '#000',
                'centerOnScroll'                : true,
                'hideOnContentClick'    : true,
                'hideOnOverlayClick'    : true,
                'autoDimensions'        : true,
                'padding'                       : 0,
                'href'                          : 'PUTYOURIMAGEHERE.jpg',
                'title'                                 : 'PUTYOURTITLEHERE',
                'transitionIn'                  : 'fade',
                'transitionOut'                 : 'fade'
        })

			$("a#example1").fancybox();

			$("a#example2").fancybox({
				'overlayShow'	: false,
				'transitionIn'	: 'fade',
				'transitionOut'	: 'fade'
			});

			$("a#example3").fancybox({
				'transitionIn'	: 'none',
				'transitionOut'	: 'none'	
			});

			$("a#example4").fancybox({
				'opacity'		: true,
				'overlayShow'	: false,
				'transitionIn'	: 'elastic',
				'transitionOut'	: 'none'
			});

			$("a#example5").fancybox();

			$("a#example6").fancybox({
				'titlePosition'		: 'outside',
				'overlayColor'		: '#000',
				'overlayOpacity'	: 0.9
			});

			$("a#example7").fancybox({
				'titlePosition'	: 'inside'
			});

			$("a#example8").fancybox({
				'titlePosition'	: 'over'
			});

			$("a[rel=example_group]").fancybox({
				'transitionIn'		: 'none',
				'transitionOut'		: 'none',
				'titlePosition' 	: 'over',
				'titleFormat'		: function(title, currentArray, currentIndex, currentOpts) {
					return '<span id="fancybox-title-over">Image ' + (currentIndex + 1) + ' / ' + currentArray.length + (title.length ? ' &nbsp; ' + title : '') + '</span>';
				}
			});

			/*
			*   Examples - various
			*/
			
			$(document).ready(function() {
 $("a.overlay-flash").fancybox({
 'padding'                : 0,
 'zoomOpacity'            : true,
 'zoomSpeedIn'            : 500,
 'zoomSpeedOut'            : 500,
 'overlayOpacity'        : 0.75,
 'frameWidth'            : 530,
 'frameHeight'            : 400,
 'hideOnContentClick'    : false
 });
});

			

			$("#various1").fancybox({
				'titlePosition'		: 'inside',
				'transitionIn'		: 'none',
				'transitionOut'		: 'none'
			});
			
							$("#various1a").fancybox({
				'titlePosition'		: 'inside',
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
			});
			
			
			$("#various1a1").fancybox({
				'titlePosition'		: 'inside',
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
			});
			
			
			$("#various1a2").fancybox({
				'titlePosition'		: 'inside',
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
			});
			
			
			$("#various1a3").fancybox({
				'titlePosition'		: 'inside',
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
			});
			
			
			
			$("#various1a4").fancybox({
				'titlePosition'		: 'inside',
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
			});
			
			
				$("#various1a5").fancybox({
				'titlePosition'		: 'inside',
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
			});
			
			
					$("#various1a6").fancybox({
				'titlePosition'		: 'inside',
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
			});
			
			$("#various1a7").fancybox({
				'titlePosition'		: 'inside',
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
			});
			
			
			$("#various1a8").fancybox({
				'titlePosition'		: 'inside',
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
			});
			
			
			$("#various1a9").fancybox({
				'titlePosition'		: 'inside',
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
			});
			
									$("#various1b").fancybox({
				'titlePosition'		: 'inside',
				'transitionIn'		: 'none',
				'transitionOut'		: 'none'
			});


				$("#various2").fancybox({
				'width'				: 780,
				'height'			: 515,
				'padding'			: 5,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
				$("#various2a").fancybox({
				'width'				: 780,
				'height'			: 420,
				'padding'			: 0,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
							$("#various2a1").fancybox({
				'width'				: 620,
				'height'			: 420,
				'padding'			: 10,
				'autoScale'			: false,
				'hideOnOverlayClick' : true,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
							$("#various2a2").fancybox({
				'width'				: 620,
				'height'			: 420,
				'padding'			: 10,
				'autoScale'			: false,
				'hideOnOverlayClick' : true,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
							$("#various2a3").fancybox({
				'width'				: 620,
				'height'			: 420,
				'padding'			: 10,
				'autoScale'			: false,
				'hideOnOverlayClick' : true,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
							$("#various2a4").fancybox({
				'width'				: 620,
				'height'			: 420,
				'padding'			: 10,
				'autoScale'			: false,
				'hideOnOverlayClick' : true,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
							$("#various2a5").fancybox({
				'width'				: 620,
				'height'			: 420,
				'padding'			: 10,
				'autoScale'			: false,
				'hideOnOverlayClick' : true,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});


				$("#various2a6").fancybox({
				'width'				: 620,
				'height'			: 420,
				'padding'			: 10,
				'autoScale'			: false,
				'hideOnOverlayClick' : true,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
			
							$("#various2a7").fancybox({
				'width'				: 620,
				'height'			: 420,
				'padding'			: 10,
				'autoScale'			: false,
				'hideOnOverlayClick' : true,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
							$("#various2a8").fancybox({
				'width'				: 620,
				'height'			: 420,
				'padding'			: 10,
				'autoScale'			: false,
				'hideOnOverlayClick' : true,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
			
							$("#various2a9").fancybox({
				'width'				: 620,
				'height'			: 420,
				'padding'			: 10,
				'autoScale'			: false,
				'hideOnOverlayClick' : true,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
					$("#ucp600a1").fancybox({
				'width'				: 620,
				'height'			: 220,
				'padding'			: 10,
				'autoScale'			: false,
				'hideOnOverlayClick' : true,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
				$("#ucp600a2").fancybox({
				'width'				: 620,
				'height'			: 220,
				'padding'			: 10,
				'autoScale'			: false,
				'hideOnOverlayClick' : true,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
				$("#pdfa1").fancybox({
				'width'				: 720,
				'height'			: 580,
				'padding'			: 10,
				'autoScale'			: false,
				'hideOnOverlayClick' : true,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
				$("#pdfa2").fancybox({
				'width'				: 720,
				'height'			: 420,
				'padding'			: 10,
				'autoScale'			: false,
				'hideOnOverlayClick' : true,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});


				$("#various2b").fancybox({
				'width'				: 780,
				'height'			: 420,
				'padding'			: 0,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
						
				$("#various2pic").fancybox({
                'autoDimensions'        : true,
				'padding'			: 5,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});



			$("#various3").fancybox({
				'width'				: 850,
				'height'			: '100%',
				'padding'			: 10,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
			
			
			$("#mainpopup").fancybox({
				'width'				: 880,
				'height'			: '100%',
				'padding'			: 10,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
			$("#mainpopup2").fancybox({
				'width'				: 880,
				'height'			: '100%',
				'padding'			: 10,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
			$("#mainpopup3").fancybox({
				'width'				: 880,
				'height'			: '100%',
				'padding'			: 10,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
					$("#mainpopup4").fancybox({
				'width'				: 880,
				'height'			: '100%',
				'padding'			: 10,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
					$("#mainpopup5").fancybox({
				'width'				: 880,
				'height'			: '100%',
				'padding'			: 10,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
					$("#mainpopup6").fancybox({
				'width'				: 880,
				'height'			: '100%',
				'padding'			: 10,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
		$("#mainpopup7").fancybox({
				'width'				: 880,
				'height'			: '100%',
				'padding'			: 10,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
					$("#mainpopup8").fancybox({
				'width'				: 880,
				'height'			: '100%',
				'padding'			: 10,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
			
					$("#mainpopup9").fancybox({
				'width'				: 880,
				'height'			: '100%',
				'padding'			: 10,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
					$("#mainpopup10").fancybox({
				'width'				: 880,
				'height'			: '100%',
				'padding'			: 10,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
			$("#various4").fancybox({
				'width'				: 780,
				'height'			: 515,
				'padding'			: 5,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
			$("#variousFL001").fancybox({
				'width'				: 760,
				'height'			: 420,
				'padding'			: 5,
				'autoScale'			: false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'hideOnOverlayClick' : false,
			});
			
				$("#variousFL002").fancybox({
				'width'				: 760,
				'height'			: 420,
				'padding'			: 5,
				'autoScale'			: false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'hideOnOverlayClick' : false,
			});
			
						$("#variousFL002").fancybox({
				'width'				: 760,
				'height'			: 420,
				'padding'			: 5,
				'autoScale'			: false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'hideOnOverlayClick' : false,
			});
		});
