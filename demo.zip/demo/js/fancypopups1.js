
		$(document).ready(function() {
		/* -------------- Main Screens ----------- */
			$("#mainpopup").fancybox({
				'onComplete'			: null,
				'width'				: 880,
				'height'			: '100%',
				'padding'			: 5,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'showCloseButton'   : false,
                'enableEscapeButton'   : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'																
				
			});
			
			$("#mainpopup2").fancybox({
				'onComplete'			: null,
				'width'				: 880,
				'height'			: '100%',
				'padding'			: 5,
				'autoScale'			: false,

				'hideOnOverlayClick' : false,
				'showCloseButton'   : false,
                'enableEscapeButton'   : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
			$("#mainpopup3").fancybox({
				'onComplete'			: null,
				'width'				: 880,
				'height'			: '100%',
				'padding'			: 5,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'showCloseButton'   : false,
                'enableEscapeButton'   : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
					$("#mainpopup4").fancybox({
				'onComplete'			: null,
				'width'				: 880,
				'height'			: '100%',
				'padding'			: 5,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'showCloseButton'   : false,
                'enableEscapeButton'   : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
					$("#mainpopup5").fancybox({
				'onComplete'			: null,
				'width'				: 880,
				'height'			: '100%',
				'padding'			: 5,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'showCloseButton'   : false,
                'enableEscapeButton'   : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
					$("#mainpopup6").fancybox({
				'onComplete'			: null,
				'width'				: 880,
				'height'			: '100%',
				'padding'			: 5,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'showCloseButton'   : false,
                'enableEscapeButton'   : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
		$("#mainpopup7").fancybox({
				'onComplete'			: null,	
				'width'				: 880,
				'height'			: '100%',
				'padding'			: 5,
				'autoScale'			: false,
			    'hideOnOverlayClick' : false,
				'showCloseButton'   : false,
                'enableEscapeButton'   : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
					$("#mainpopup8").fancybox({
				'onComplete'			: null,
				'width'				: 880,
				'height'			: '100%',
				'padding'			: 5,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'showCloseButton'   : false,
                'enableEscapeButton'   : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
			
					$("#mainpopup9").fancybox({
				'onComplete'			: null,	
				'width'				: 880,
				'height'			: '100%',
				'padding'			: 5,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'showCloseButton'   : false,
                'enableEscapeButton'   : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
					$("#mainpopup10").fancybox({
				'onComplete'			: null,	
				'width'				: 880,
				'height'			: '100%',
				'padding'			: 5,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'showCloseButton'   : false,
                'enableEscapeButton'   : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
			$("#mainpopup11").fancybox({
				'onComplete'			: null,	
				'width'				: 880,
				'height'			: '100%',
				'padding'			: 5,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'showCloseButton'   : false,
                'enableEscapeButton'   : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
				/* Main Screens End */
				
						/* ------------- Case studies ---------- */
						
						$("#casestudies").fancybox({
				'onComplete'			: null,	
				'width'				: 770,
				'height'			: 510,
				'padding'			: 5,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'showCloseButton'   : false,
                'enableEscapeButton'   : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});		
			
									$("#casestudies2").fancybox({
				'onComplete'			: null,	
				'width'				: 880,
				'height'			: '100%',
				'padding'			: 5,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'showCloseButton'   : false,
                'enableEscapeButton'   : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});		
			
												$("#casestudies3").fancybox({
				'onComplete'			: null,	
				'width'				: 880,
				'height'			: '100%',
				'padding'			: 5,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'showCloseButton'   : false,
                'enableEscapeButton'   : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});		
					
					
					$("#casestudies4").fancybox({
				'onComplete'			: null,	
				'width'				: 880,
				'height'			: '100%',
				'padding'			: 5,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'showCloseButton'   : false,
                'enableEscapeButton'   : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});									/* Case studies End */
			
			/* -------------Assessment ---------*/
						$("#assessment").fancybox({
				'onComplete'			: null,	
				'width'				: 880,
				'height'			: '100%',
				'padding'			: 5,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'showCloseButton'   : false,
                'enableEscapeButton'   : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});			
			
						/* Assessment End  */

				$("#various2a").fancybox({
				'onComplete'			: null,	
				'width'				: 780,
				'height'			: '80%',
				'padding'			: 0,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'showCloseButton'   : false,
                'enableEscapeButton'   : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
			
			
			/* --------Additional popups -------- */
			
				/* Opinions  */		
			
							$("#various2a1").fancybox({
				'onComplete'			: null,	
				'width'				: 620,
				'height'			: '80%',
				'padding'			: 0,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'showCloseButton'   : false,
                'enableEscapeButton'   : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
							$("#various2a2").fancybox({
				'onComplete'			: null,	
				'width'				: 620,
				'height'			: '80%',
				'padding'			: 0,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'showCloseButton'   : false,
                'enableEscapeButton'   : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
							$("#various2a3").fancybox({
				'onComplete'			: null,	
				'width'				: 620,
				'height'			: '80%',
				'padding'			: 0,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'showCloseButton'   : false,
                'enableEscapeButton'   : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
							$("#various2a4").fancybox({
				'onComplete'			: null,	
				'width'				: 620,
				'height'			: '80%',
				'padding'			: 0,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'showCloseButton'   : false,
                'enableEscapeButton'   : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
							$("#various2a5").fancybox({
				'onComplete'			: null,	
				'width'				: 620,
				'height'			: '80%',
				'padding'			: 0,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'showCloseButton'   : false,
                'enableEscapeButton'   : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});


				$("#various2a6").fancybox({
				'onComplete'			: null,	
				'width'				: 620,
				'height'			: '80%',
				'padding'			: 0,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'showCloseButton'   : false,
                'enableEscapeButton'   : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
			
							$("#various2a7").fancybox({
				'onComplete'			: null,	
				'width'				: 620,
				'height'			: '80%',
				'padding'			: 0,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'showCloseButton'   : false,
                'enableEscapeButton'   : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
							$("#various2a8").fancybox({
				'onComplete'			: null,	
				'width'				: 620,
				'height'			: '80%',
				'padding'			: 0,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'showCloseButton'   : false,
                'enableEscapeButton'   : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
			
							$("#various2a9").fancybox({
				'onComplete'			: null,	
				'width'				: 620,
				'height'			: '80%',
				'padding'			: 0,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'showCloseButton'   : false,
                'enableEscapeButton'   : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
					$("#ucp600a1").fancybox({
				'onComplete'			: null,	
				'width'				: 620,
				'height'			: '80%',
				'padding'			: 0,
				'autoScale'			: false,

				'hideOnOverlayClick' : false,
				'showCloseButton'   : false,
                'enableEscapeButton'   : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
				$("#ucp600a2").fancybox({
				'onComplete'			: null,	
				'width'				: 620,
				'height'			: '80%',
				'padding'			: 0,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'showCloseButton'   : false,
                'enableEscapeButton'   : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
				$("#ucp600a3").fancybox({
				'onComplete'			: null,	
				'width'				: 620,
				'height'			: '80%',
				'padding'			: 0,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'showCloseButton'   : false,
                'enableEscapeButton'   : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
	
				$("#ucp600a4").fancybox({
				'onComplete'			: null,	
				'width'				: 620,
				'height'			: '80%',
				'padding'			: 0,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'showCloseButton'   : false,
                'enableEscapeButton'   : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
				$("#ucp600a5").fancybox({
				'onComplete'			: null,	
				'width'				: 620,
				'height'			: '80%',
				'padding'			: 0,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'showCloseButton'   : false,
                'enableEscapeButton'   : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
				$("#ucp600a6").fancybox({
				'onComplete'			: null,	
				'width'				: 620,
				'height'			: '80%',
				'padding'			: 0,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'showCloseButton'   : false,
                'enableEscapeButton'   : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
							$("#ucp600a7").fancybox({
				'onComplete'			: null,	
				'width'				: 620,
				'height'			: '80%',
				'padding'			: 0,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'showCloseButton'   : false,
                'enableEscapeButton'   : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
							$("#ucp600a8").fancybox({
				'onComplete'			: null,	
				'width'				: 620,
				'height'			: '80%',
				'padding'			: 0,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'showCloseButton'   : false,
                'enableEscapeButton'   : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
							$("#ucp600a9").fancybox({
				'onComplete'			: null,	
				'width'				: 620,
				'height'			: '80%',
				'padding'			: 0,
				'autoScale'			: false,
				'hideOnOverlayClick' : false,
				'showCloseButton'   : false,
                'enableEscapeButton'   : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
				

			
		$("#pdfa1").fancybox({
				'onComplete'			: null,	
				'width'				: 720,
				'height'			: '80%',
				'padding'			: 0,
				'autoScale'			: false,
				'hideOnOverlayClick' : true,
				'showCloseButton'   : true,
                'enableEscapeButton'   : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
				$("#pdfa2").fancybox({
				'onComplete'			: null,	
				'width'				: 720,
				'height'			: '80%',
				'padding'			: 0,
				'autoScale'			: false,
				'hideOnOverlayClick' : true,
				'showCloseButton'   : true,
                'enableEscapeButton'   : false,
				'transitionIn'		: 'fade',
				'transitionOut'		: 'fade',
				'type'				: 'iframe'
				
			});
			
			
		$(document).ready(function() {
 $("a.overlay-flash").fancybox({
 'padding'                : 0,
 'zoomOpacity'            : true,
 'zoomSpeedIn'            : 500,
 'zoomSpeedOut'            : 500,
 'overlayOpacity'        : 0.75,
 'frameWidth'            : 530,
 'frameHeight'            : 400,
 'hideOnContentClick'    : false
 });
});


		});
