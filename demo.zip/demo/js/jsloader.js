function loadjscssfile(filename, filetype){
 if (filetype=="js"){ //if filename is a external JavaScript file
  var fileref=document.createElement('script')
  fileref.setAttribute("type","text/javascript")
  fileref.setAttribute("src", filename)
 }
 else if (filetype=="css"){ //if filename is an external CSS file
  var fileref=document.createElement("link")
  fileref.setAttribute("rel", "stylesheet")
  fileref.setAttribute("type", "text/css")
  fileref.setAttribute("href", filename)
 }
 
 if (typeof fileref!="undefined")
  document.getElementsByTagName("head")[0].appendChild(fileref)
}


function addLoadEvent(func) {   
   var oldonload = window.onload;   
   if (typeof window.onload != 'function') {   
     window.onload = func;   
   } else {   
     window.onload = function() {   
       if (oldonload) {   
         oldonload();   
       }   
       func();   
     }   
   }   
 }   
 
 
 
   
	       
//css loader
//loadjscssfile("css/pagestyles.css", "css") ////page contruction

/*Jquery General*/
 addLoadEvent(function() { loadjscssfile("js/jquery-1.4.2.min.js", "js"); })   //jquery

/*rounded cornes*/
 addLoadEvent(function() { loadjscssfile("js/dd_roundies_0.0.2a-min.js", "js"); })  
 addLoadEvent(function() { loadjscssfile("js/dd_rounds.js", "js"); })  
 
  /*Galleries*/
 addLoadEvent(function() { loadjscssfile("js/jquery.mousewheel-3.0.2.pack.js", "js"); })  
 addLoadEvent(function() { loadjscssfile("js/jquery.fancybox-1.3.1.js", "js"); })  
 addLoadEvent(function() { loadjscssfile("js/jquery.fancybox-options.js", "js"); })  

  /*Loginslider*/
 addLoadEvent(function() { loadjscssfile("js/slide.js", "js"); })  


